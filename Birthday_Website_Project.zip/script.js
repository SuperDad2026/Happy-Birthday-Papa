const photos=['photo1.jpg','photo2.jpg','photo3.jpg','photo4.jpg'];let index=0;
function startSurprise(){welcome.style.display='none';gallery.style.display='flex';balloons();slideshow();setTimeout(()=>{gallery.style.display='none';message.style.display='flex';confetti();},16000);}
function slideshow(){const img=document.getElementById('slide');setInterval(()=>{index=(index+1)%photos.length;img.src=photos[index];},4000);}
function balloons(){setInterval(()=>{const b=document.createElement('div');b.className='balloon';b.innerHTML='🎈';b.style.left=Math.random()*100+'vw';document.body.appendChild(b);setTimeout(()=>b.remove(),10000);},500);}
function confetti(){}